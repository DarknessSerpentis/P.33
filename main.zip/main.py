import random
from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scatter import Scatter


class myApp(App):
    def build(self):
        fl = FloatLayout(size=(200, 200), pos_hint={'center_y': .4, 'center_x': .5})
        fl.add_widget(Button(
            text="Кнопка 2",
            font_size=20,
            on_press=self.btn_press,
            background_color=[1, 1, 0, 1],
            background_normal='',
            size_hint=(.5, .25),
            pos_hint={'center_y': .5, 'center_x': .5}));
        fl.add_widget(Button(
            text='Кнопка 1',
            font_size=20,
            on_press=self.btn2_press,
            background_color=[1, 0, 0, 1],
            background_normal='',
            size_hint=(.5, .25),
            pos_hint={'center_y': .8, 'center_x': .5}));
        return fl

    def btn_press(self, instance):
        instance.text = 'Вторая кнопка нажата'

    def btn2_press(self, instance):
        instance.text = "Первая кнопка нажата"


if __name__ == "__main__":
    myApp().run()